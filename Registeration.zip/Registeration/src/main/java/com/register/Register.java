package com.register;

import jakarta.servlet.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.*;
import java.sql.*;

@WebServlet("/registerForm")
public class Register extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String uname = request.getParameter("uname");
		String email = request.getParameter("email");
		String pass = request.getParameter("pass");
		
		String url = "jdbc:mysql://localhost:3306/register";
		String user = "root";
		String password = "Murugan@58";
		
		PrintWriter out = response.getWriter();
	
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, user, password);
			
			PreparedStatement ps = con.prepareStatement("insert into student values(?,?,?)");
			ps.setString(1, uname);
			ps.setString(2, email);
			ps.setString(3, pass);
			
			int result = ps.executeUpdate();
			
			if(result>0) {
				response.setContentType("text/html");
				RequestDispatcher rd = request.getRequestDispatcher("/index.jsp");
				rd.include(request, response);
				out.println("<h3 style='color:green'>Successfully registered Thank you for registering!...</h3>");
			}
			else {
				response.setContentType("text/html");
				RequestDispatcher rd = request.getRequestDispatcher("/index.jsp");
				rd.include(request, response);
				out.println("<h3 style='color:red'>Not registered please check!</h3>");
			}
		}
		catch(Exception e) {
			e.printStackTrace();
//			response.setContentType("text/html");
//			RequestDispatcher rd = request.getRequestDispatcher("/index.jsp");
//			rd.include(request, response);
//			out.println("<h3 style='color:red'>Not registered please check! There is some error occurs...</h3>");
		}
	}

}
