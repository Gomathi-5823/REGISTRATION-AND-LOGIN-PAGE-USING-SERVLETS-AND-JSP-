package com.register;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/login")
public class LoginServlet extends HttpServlet{

	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String email = req.getParameter("email");
		String pass = req.getParameter("password");
		
		String url = "jdbc:mysql://localhost:3306/register";
		String user = "root";
		String password = "Murugan@58";
		
		PrintWriter out = resp.getWriter();
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, user, password);
			
			PreparedStatement ps = con.prepareStatement("Select * from student where email=? and password=?");
			ps.setString(1, email);
			ps.setString(2, pass);
			ResultSet rs = ps.executeQuery();
			
			
			if(rs.next()) {
				resp.setContentType("text/html");
				HttpSession session = req.getSession();
				session.setAttribute("session_name", rs.getString("name"));
				RequestDispatcher rd = req.getRequestDispatcher("/profile.jsp");
				rd.include(req, resp);
			}
			
			else {
				resp.setContentType("text/html");
				out.println("<h3 style='color:red'>Login not successfull please check the details!...</h3>");
				RequestDispatcher rd = req.getRequestDispatcher("/login.jsp");
				rd.include(req, resp);
			}
		}
		
		catch(Exception e) {
//			resp.setContentType("text/html");
//			out.println("<h3 style='color:red'>Exception Occured!...</h3>");
//			RequestDispatcher rd = req.getRequestDispatcher("/login.jsp");
//			rd.include(req, resp);
			e.printStackTrace();
		}
		
		
		
	}
	
}
